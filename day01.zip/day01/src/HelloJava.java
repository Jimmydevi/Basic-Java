
public class HelloJava {
	
	public static void main(String[] args) {
		// sysout치고 + ctrl + space bar
		System.out.println("Hello World!");	
	
	}
	

}